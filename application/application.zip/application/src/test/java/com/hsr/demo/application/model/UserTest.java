package com.hsr.demo.application.model;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void getId() {
    }

    @Test
    public void setId() {
    }

    @Test
    public void getUserName() {
    }

    @Test
    public void setUserName() {
    }

    @Test
    public void getPassword() {
    }

    @Test
    public void setPassword() {
    }

    @Test
    public void getFirstName() {
    }

    @Test
    public void setFirstName() {
    }

    @Test
    public void getMidName() {
    }

    @Test
    public void setMidName() {
    }

    @Test
    public void getLastName() {
    }

    @Test
    public void setLastName() {
    }

    @Test
    public void getPhone() {
    }

    @Test
    public void setPhone() {
    }

    @Test
    public void getEmailAddress() {
    }

    @Test
    public void setEmailAddress() {
    }

    @Test
    public void getAddressLine() {
    }

    @Test
    public void setAddressLine() {
    }

    @Test
    public void getCity() {
    }

    @Test
    public void setCity() {
    }

    @Test
    public void getState() {
    }

    @Test
    public void setState() {
    }

    @Test
    public void getZipCode() {
    }

    @Test
    public void setZipCode() {
    }

    @Test
    public void getCountry() {
    }

    @Test
    public void setCountry() {
    }

    @Test
    public void getCreateDate() {
    }

    @Test
    public void setCreateDate() {
    }

    @Test
    public void getRole() {
    }

    @Test
    public void setRole() {
    }
}